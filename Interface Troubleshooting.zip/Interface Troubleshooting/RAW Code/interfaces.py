####################################################################################################
## KLEAR, N SCOTT 
## Cisco Systems, Inc.
## July 2, 2019
##
## Purpose: Different interface API Calls that can be leveraged against IOS-XE devices
## References: https://www.cisco.com/c/en/us/td/docs/routers/csr1000/software/restapi/restapi/RESTAPIclient.html
####################################################################################################

import json #convert JSON to string
import requests #Make API Call
import urllib3 #Surpress warnings
import paramiko #Make SSH call
import re #Read Regex
import time #Sleep Function

#supress SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

#getInterfaces: Provide a list of interfaces for other API calls to leverage and loop through
def getInterfaces(IPAddress, token, silent=True, APIPort=55443) :
    #Set API URL
    url = "https://%s:%d/api/v1/interfaces" % (IPAddress, APIPort)

    #Set API Headers
    headers = {
        'accept': "application/json",
        'cache-control': "no-cache",
        'x-auth-token': token
        }

    #Issue API Call
    response = requests.request("GET", url, headers=headers, verify=False)
    
    #Translate JSON data into text
    myTable = json.loads(response.text)['items']

    interfaceNames = []
    #Loop through JSON data to pull out property: if-name and add into table
    for entry in myTable :
        interfaceNames.append(entry['if-name'])

    return interfaceNames

#printInterfaces: Make API call against IOS-XE devices and prints a list of interfaces
def printInterfaces(IPAddress, token, APIPort=55443) :
    #Set API URL
    url = "https://%s:%d/api/v1/interfaces" % (IPAddress, APIPort)

    #Set API Headers
    headers = {
        'accept': "application/json",
        'cache-control': "no-cache",
        'x-auth-token': token
        }

    #Issue API Call
    response = requests.request("GET", url, headers=headers, verify=False)
    
    #Translate JSON data into text
    myTable = json.loads(response.text)['items']

    #Table Header
    print('------------------------------------')
    print('INTERFACE DETAILS')

    #Loop through data and print interface data
    for entry in myTable :
        print('-----')
        print('Interface Name: ' + entry['if-name'])
        print('Interface Description: ' + entry['description'])
        print('IP Address: ' + entry['ip-address'])
        print('Subnet Mask: ' + entry['subnet-mask'])
    print('------------------------------------')

#printInterfaceStatus: Prints a list of all interfaces and their current status
def printInterfaceStatus(IPAddress, token, user, pw, APIPort=55443) :
    myInterfaces =[]
    #Get a list of all interfaces
    myInterfaces = getInterfaces(IPAddress, token)

    #invoke SSH Client, set parameters, and invoke the shell on variable myConnection
    connection = paramiko.SSHClient()
    connection.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    connection.connect(IPAddress,username=user,password=pw,look_for_keys=False,allow_agent=False)
    myConnection = connection.invoke_shell()

    #Table Header
    print('------------------------------------')
    print('INTERFACE STATUS')

    for entry in myInterfaces :
        #Send Show IP Interface Brief | include %entry% for interface name
        myConnection.send('sh ip int br | i ' + entry + '\n')

        #Pause for terminal to catch up
        time.sleep(2)

        #Read in all data output by terminal
        output = myConnection.recv(1000)

        #Line Break
        print('-----')

        #Search regex output for up, output 
        if re.search(r'\bup\b',str(output)) :
            print('%s is Up' % entry)
        #Search regex output for administratively down, output 
        elif re.search(r'\badministratively down\b',str(output)) :
            print('%s is Administratively Down' % entry)
        #Search regex output for down, output 
        elif re.search(r'\bdown\b',str(output)) :
            print('%s is Down' % entry)
        #All else fails, print an error
        else :
            print('Error Obtaining Interface Status')
    #Table Footer
    print('------------------------------------')

    myConnection.close()

#printInterfaceStatistics: Prints Interface Statistics to include packet drops, QoS Errors
def printInterfaceStatistics(IPAddress, token, APIPort=55443) :
    interfaces = getInterfaces(IPAddress, token)

    #Print Table Header
    print('------------------------------------')
    print('INTERFACE STATISTICS')

    #The API Call for Interface State is a single interface but we need the interface ID from the previous call, so we need to loop 
    for entry in interfaces :
        url = "https://%s:%d/api/v1/interfaces/%s/statistics" % (IPAddress, APIPort, entry)
        
        #Set API Headers
        headers = {
        'accept': "application/json",
        'cache-control': "no-cache",
        'x-auth-token': token
        }

        #Issue API Call
        response = requests.request("GET", url, headers=headers, verify=False)
    
        #Translate JSON data into text
        newTable = json.loads(response.text)
        

        print('------------------------------------')
        print('Interface Name: ' + entry)
        print('-----')
        print('Input Errors: ' + str(newTable['in-errors']))
        print('Input Packet Drops: ' + str(newTable['in-packet-drops']))
        print('Input Total Packets: ' + str(newTable['in-total-packets']))
        print('-----')
        print('Output Errors: ' + str(newTable['out-errors']))
        print('Output Packet Drops: ' + str(newTable['out-packet-drops']))
        print('Output Total Packets: ' + str(newTable['out-total-packets']))
        
    print('------------------------------------')
        
def analyzeInterfaceStatistics(IPAddress, token, APIPort=55443) :
    interfaces = getInterfaces(IPAddress, token)

    #Print Table Header
    print('------------------------------------')
    print('INTERFACE ANALYSIS')

    #The API Call for Interface State is a single interface but we need the interface ID from the previous call, so we need to loop 
    for entry in interfaces :
        url = "https://%s:%d/api/v1/interfaces/%s/statistics" % (IPAddress, APIPort, entry)
        
        #Set API Headers
        headers = {
        'accept': "application/json",
        'cache-control': "no-cache",
        'x-auth-token': token
        }

        #Issue API Call
        response = requests.request("GET", url, headers=headers, verify=False)
    
        #Translate JSON data into text
        newTable = json.loads(response.text)

        #Calulate Percentage with Input errors
        try:
            inputErrors = newTable['in-errors'] / newTable['in-total-packets']
        except ZeroDivisionError:
            inputErrors = 0

        #Calulate Percentage with Input Drops
        try:
            inputDrops = newTable['in-packet-drops'] / newTable['in-total-packets']
        except ZeroDivisionError:
            inputDrops = 0

        #Calulate Percentage with Output errors
        try:
            outputErrors = newTable['out-errors'] / newTable['out-total-packets']
        except ZeroDivisionError:
            outputErrors = 0

        #Calulate Percentage with Output Drops
        try:
            outputDrops = newTable['out-packet-drops'] / newTable['out-total-packets']
        except ZeroDivisionError:
            outputDrops = 0
           
        print('------------------------------------')
        print('Interface Name: ' + entry)
        print('-----')
        print('Input Total Packets: ' + str(newTable['in-total-packets']))
        print('Percentage with Input Errors: %1.2f' % inputErrors)
        print('Percentage with Input Packet Drops: %1.2f' % inputDrops)
        print('-----')
        print('Output Total Packets: ' + str(newTable['out-total-packets']))
        print('Percentage with Output Errors: %1.2f' % outputErrors)
        print('Percentage with Output Packet Drops: %1.2f' % outputDrops)
        
        
    print('------------------------------------')

def checkInterfaceDescription(IPAddress, token, user, pw, APIPort=55443) :
    #Set API URL to grab list of Interfaces and their details
    url = "https://%s:%d/api/v1/interfaces" % (IPAddress, APIPort)

    #Set API Headers
    headers = {
        'accept': "application/json",
        'cache-control': "no-cache",
        'x-auth-token': token
        }

    #Issue API Call
    response = requests.request("GET", url, headers=headers, verify=False)
    
    #Translate JSON data into text
    myTable = json.loads(response.text)['items']

    #Define noDescTable
    noDescTable = []

    #Loop through all interfaces and add if-name to noDescTable if they do not have a description
    for entry in myTable :
        if entry['description'] == '' :
            noDescTable.append(entry['if-name'])

    #No API currently exist to tell if an interface is 'Administratively Down' only 'Down', so we'll go the legacy route
    #invoke SSH Client, set parameters, and invoke the shell on variable myConnection
    connection = paramiko.SSHClient()
    connection.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    connection.connect(IPAddress,username=user,password=pw,look_for_keys=False,allow_agent=False)
    myConnection = connection.invoke_shell()

    #Table Header
    print('''-------------------------------------
INTERFACES WITHOUT A DESCRIPTION THAT 
ARE NOT ADMINISTRATIVELY DOWN
-------------------------------------''')

    for entry in noDescTable :
        #Send Show IP Interface Brief | include %entry% for interface name
        myConnection.send('sh run int %s | i shut\n' % entry)

        #Pause for terminal to catch up
        time.sleep(3)

        #Read in all data output by terminal
        output = myConnection.recv(200)

        #Search regex output for administratively down, output 
        if re.search(r'\bshutdown\b',str(output)) :
            continue
        #If we can't find shutdown, print the interface
        else :
            print(entry)
    #Table Footer
    print('-----')

    #Close the SSH connection
    myConnection.close()

    
            
