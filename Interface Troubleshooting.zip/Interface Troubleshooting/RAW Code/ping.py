####################################################################################################
## KLEAR, N SCOTT 
## Cisco Systems, Inc.
## July 2, 2019
##
## Purpose: Checks for device connectivity in the background, returns boolean for reachable or not. Optional parameter to run in silent mode.
####################################################################################################

import ipaddress #IP Address tool for validating IP info
import subprocess #Run processes silently in background

def pingCheck(strIPAddress, silent=False):
    try:
        #Turns string into an IPv4 Object to validate it is an IP
        ip = ipaddress.ip_address(strIPAddress)

        #Prints successful message that it is a valid IP Address
        if silent == False:
            print('%s is a correct IP%s address.' % (ip, ip.version))

        #Checks in the background to see if the IP is reachable
        subprocess.check_output(["ping", "-c", "1", strIPAddress])
    except:
        #If an error occurs anywhere, returns that the address is not reachable
        if silent == False:
            print('%s is not reachable' % strIPAddress)
        return False

    #If successful, returns that the address is reachable
    if silent == False:
        print('The Network Device is Reachable')

    #Return that the device is reachable if no other errors identified    
    return True

