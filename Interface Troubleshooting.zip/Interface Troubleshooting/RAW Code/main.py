####################################################################################################
## KLEAR, N SCOTT 
## Cisco Systems, Inc.
## July 2, 2019
##
## Purpose: Health Checker to pull interface statistics and compare them against traffic being sent
####################################################################################################

import ping #Network connectivity testing
import tokens #Grab token from IOS-XE device
import interfaces #interfaces toolkit

#Print out Welcome Message
print('''
===============================================
== Welcome to the Network Interface Analyzer == 
== Please ensure your device supports IOS-XE ==
===============================================
''')

#Loop: Request Network Device IP Address, check for Network Device connectivity, Continue once good Network Device is found
bolIP = False
while bolIP == False :
    IPAddress = input('Please input the network endpoints IP Address (x.x.x.x): ') 

    #Executes ping check, runs in silent mode
    bolIP = ping.pingCheck(IPAddress, True)

#Get a token, pass IP Address, Username and Password all input by user, if token grab is successful, break loop
tokenID, opaqueTokenID, user, password = tokens.grabToken(IPAddress, silent=True)

continueLoop = True
while continueLoop :
    #Request what they want to do: 1) Interface Status 2) Interface Statistics 3) Interface Analysis 
    option = input('''
    What would you like to do?
    
    (1) Interface Info: Print Interface Details
    (2) Interface Status: Print whether Interface is up or down 
    (3) Interface Statistics: Print Interface Statistics 
    (4) Analyze Interface Statistics: Print Statistics compared to total traffic transmitted/received
    (5) Check Interfaces Descriptions: Ensure only Administratively Down ports have no Description
    (6) Exit the Program 
    
    Your Choice: ''')

    #If Option 1: Check Interface Status
    if option == '1' :
        interfaces.printInterfaces(IPAddress, tokenID)
    #If Option 2: Check Interface Status
    elif option == '2' :
        interfaces.printInterfaceStatus(IPAddress, tokenID, user, password)
    #If Option 3: Get Interface Statistics
    elif option == '3' :
        interfaces.printInterfaceStatistics(IPAddress, tokenID)
    #If Option 4: Analyze Interface Statistics
    elif option == '4' :
        interfaces.analyzeInterfaceStatistics(IPAddress, tokenID)
    #If Option 5: Check Interface Descriptions
    elif option == '5' :
        interfaces.checkInterfaceDescription(IPAddress, tokenID, user, password)
    #If option 6, break loop and end program
    elif option == '6' :
        tokens.revokeToken(IPAddress, tokenID, opaqueTokenID)
        print('\nGood Bye')
        break
    else :
        print('Invalid Choice')
    
