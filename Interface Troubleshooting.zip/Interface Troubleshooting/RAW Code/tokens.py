####################################################################################################
## KLEAR, N SCOTT 
## Cisco Systems, Inc.
## July 2, 2019
##
## Purpose: Grab token from router, return token
## References: https://www.cisco.com/c/en/us/td/docs/routers/csr1000/software/restapi/restapi/RESTAPIclient.html
####################################################################################################

import json #convert JSON to string
import requests #Make API Call
import urllib3 #Surpress warnings
import getpass #Password Suppression
import sys #Used to kill program

#supress SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def grabToken(IPAddress, silent=False, APIPort=55443) :
    #Define token API Address with passed variables
    url = 'https://%s:%d/api/v1/auth/token-services' % (IPAddress, APIPort)

    #Define headers required to make the API call
    headers = {
        'Accept': "application/json",
        'cache-control': "no-cache",
        }

    try:
        tokenNumAttempts = 0
        #Loop: Request User Name / Password, try until good password, pull token from device
        while tokenNumAttempts < 3 :
            tokenNumAttempts += 1

            #Request user for username and password, use getpass to conceal password upon input
            user = input('\nPlease provide your username for %s: ' % IPAddress)
            password = getpass.getpass()
                      
            #Make API Call to device
            response = requests.request("POST", url, auth=(user,password), headers=headers, verify=False)

            #If status_code = 200 (Successful API Call), return token. Else: Return Error Code
            if response.status_code == 200:
                token = json.loads(response.text)
                #return token, last 10 characters of link for reference to revoke token later
                return token['token-id'], token['link'][-10:], user, password
        else:
            print('Invalid Username/Password')
            sys.exit()
    except:
        print('Unknown API Error.')
        sys.exit()
    
        

#Used to revoke the token, default parameter runs this with feedback
def revokeToken (IPAddress, token, opaqueToken, silent=False, APIPort=55443) :
    #Define token API url address
    url = 'https://%s:%d/api/v1/auth/token-services/%s' % (IPAddress, APIPort, opaqueToken)

    headers = {
        'x-auth-token': token,
        'Cache-Control': "no-cache",
        }
    
    #Execute API Call, revoking the token used during this session
    response = requests.request("DELETE", url, headers=headers, verify=False)

    #Give feedback if Silent mode is Off
    if silent == False :
        if response.status_code == 204 :
            print('Token Revocation Successful')
        else :
            print('Token Revocation Unsuccessful')


